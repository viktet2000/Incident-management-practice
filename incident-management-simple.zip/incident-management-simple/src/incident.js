// Simple incident management practice project.
// Business rules are documented in README.md.

function getPriority(impact, urgency) {
  const allowed = ['high', 'low'];
  if (!allowed.includes(impact) || !allowed.includes(urgency)) {
    throw new Error('Invalid impact or urgency');
  }

  if (impact === 'high' && urgency === 'high') return 'P1';
  if (impact === 'high' && urgency === 'low') return 'P2';
  return 'P3';
}

function shouldEscalate(priority) {
  return priority === 'P1';
}

module.exports = { getPriority, shouldEscalate };
