const test = require('node:test');
const assert = require('node:assert/strict');
const { getPriority, shouldEscalate } = require('../src/incident');

test('high impact and high urgency is P1', () => {
  assert.equal(getPriority('high', 'high'), 'P1');
});

test('high impact and low urgency is P2', () => {
  assert.equal(getPriority('high', 'low'), 'P2');
});

test('low impact and high urgency is P2', () => {
  assert.equal(getPriority('low', 'high'), 'P2');
});

test('low impact and low urgency is P3', () => {
  assert.equal(getPriority('low', 'low'), 'P3');
});

test('invalid impact is rejected', () => {
  assert.throws(() => getPriority('unknown', 'low'), /Invalid/);
});

test('invalid urgency is rejected', () => {
  assert.throws(() => getPriority('low', 'unknown'), /Invalid/);
});

test('only P1 requires immediate escalation', () => {
  assert.equal(shouldEscalate('P1'), true);
  assert.equal(shouldEscalate('P2'), false);
  assert.equal(shouldEscalate('P3'), false);
});
