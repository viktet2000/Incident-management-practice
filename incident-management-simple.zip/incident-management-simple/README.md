# Simple Incident Management — JavaScript Practice

A standalone educational project for practising JavaScript debugging and automated testing. **Not a prepared submission for a live assessment.**

## Business requirements

- High impact + high urgency => P1.
- Exactly one of impact and urgency is high => P2.
- Low impact + low urgency => P3.
- Invalid impact or urgency must be rejected.
- Only P1 incidents require immediate escalation.

## Run the tests

Install Node.js 18 or newer, open a terminal in this folder, and run:

```bash
npm test
```

There is an intentional logic defect in `src/incident.js`. Investigate the failing test, correct the implementation, and rerun the tests. Do not change the test expectations to hide the defect.

## Files

- `src/incident.js` — implementation
- `test/incident.test.js` — automated tests
- `package.json` — test command

## GitHub

Upload these files to a repository you control. If publishing publicly, choose a licence you are entitled to grant (for example MIT for code you own). Do not upload secrets or private assessment materials.
